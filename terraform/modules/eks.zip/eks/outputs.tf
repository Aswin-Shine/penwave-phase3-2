output "cluster_name" {
  description = "EKS cluster name."
  value       = aws_eks_cluster.main.name
}

output "cluster_endpoint" {
  description = "EKS API server endpoint."
  value       = aws_eks_cluster.main.endpoint
}

output "cluster_ca_certificate" {
  description = "Base64 encoded CA certificate for the cluster, needed for kubeconfig."
  value       = aws_eks_cluster.main.certificate_authority[0].data
}

output "cluster_arn" {
  description = "EKS cluster ARN."
  value       = aws_eks_cluster.main.arn
}

output "oidc_provider_arn" {
  description = "IAM OIDC provider ARN. Used in IRSA role trust policies."
  value       = aws_iam_openid_connect_provider.eks.arn
}

output "oidc_provider_url" {
  description = <<-EOT
    OIDC issuer URL WITHOUT the https:// prefix.
    IAM trust policy Condition keys require the bare host+path form,
    e.g. oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE rather than
    https://oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE — stripping the
    scheme here means every consumer of this output doesn't need to
    repeat the replace() call.
  EOT
  value = replace(aws_eks_cluster.main.identity[0].oidc[0].issuer, "https://", "")
}

output "cluster_role_arn" {
  description = "IAM role ARN of the cluster control plane."
  value       = aws_iam_role.cluster.arn
}

output "node_role_arn" {
  description = "IAM role ARN assumed by Auto Mode nodes."
  value       = aws_iam_role.node.arn
}
