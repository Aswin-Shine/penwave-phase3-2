variable "project" {
  description = "Project name prefix."
  type        = string
}

variable "environment" {
  description = "Environment name."
  type        = string
}

variable "aws_region" {
  description = "AWS region."
  type        = string
}

variable "cluster_name" {
  description = "EKS cluster name."
  type        = string
}

variable "cluster_version" {
  description = "Kubernetes version for the EKS control plane."
  type        = string
}

variable "vpc_id" {
  description = "VPC ID."
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for node placement."
  type        = list(string)
}

variable "public_subnet_ids" {
  description = "Public subnet IDs. Included in cluster vpc_config so the ALB controller can place internet facing load balancers."
  type        = list(string)
}

variable "cluster_security_group_id" {
  description = "Additional security group ID for the cluster control plane ENIs."
  type        = string
}

variable "node_security_group_id" {
  description = <<-EOT
    Node security group ID. NOTE: Auto Mode manages its own node security
    group internally and does not accept a custom one via compute_config.
    This variable is accepted for interface consistency with the security
    module and reserved for future use if AWS adds support, or if you
    switch from Auto Mode to managed node groups later.
  EOT
  type        = string
}

variable "node_instance_types" {
  description = "Instance types Auto Mode node pools are allowed to launch."
  type        = list(string)
}

variable "node_capacity_type" {
  description = "ON_DEMAND or SPOT."
  type        = string
}

variable "node_pools" {
  description = <<-EOT
    Auto Mode built in node pool names to enable.
    "general-purpose": standard workloads (frontend, backend pods).
    "system": reserved for system pods (CoreDNS, ALB controller, etc.)
    so application pods can't starve cluster critical components.
  EOT
  type    = list(string)
  default = ["general-purpose", "system"]
}

variable "cluster_public_access_cidrs" {
  description = <<-EOT
    CIDRs allowed to reach the public Kubernetes API endpoint.
    Default 0.0.0.0/0 for learning project convenience (kubectl from
    anywhere). Restrict to your IP/32 for anything longer lived.
  EOT
  type    = list(string)
  default = ["0.0.0.0/0"]
}

variable "aws_account_id" {
  description = "AWS account ID, for constructing ARNs."
  type        = string
}
